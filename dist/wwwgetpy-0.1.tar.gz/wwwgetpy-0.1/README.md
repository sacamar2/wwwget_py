# wwwget_py
It is a Windows WSL wget python lib to use it for HTML folder directories in paralel
